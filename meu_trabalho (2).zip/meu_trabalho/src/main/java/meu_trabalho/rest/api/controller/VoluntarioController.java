package meu_trabalho.rest.api.controller;

import meu_trabalho.rest.api.model.UsuarioModel;
import meu_trabalho.rest.api.model.VoluntarioModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import meu_trabalho.rest.api.repository.VoluntarioRepository;

@RestController
public class VoluntarioController {

    @Autowired
    private VoluntarioRepository repository;

    @GetMapping(path = "/api/voluntario/{codigo}")
    public ResponseEntity consultar2(@PathVariable("codigo") Integer codigo) {
        return repository.findById(codigo)
                .map(record -> ResponseEntity.ok().body(record))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping(path = "/api/voluntario/salvar")
    public VoluntarioModel salvar2(@RequestBody VoluntarioModel voluntario) {
        return repository.save(voluntario);
    }


    @DeleteMapping(path = "/api/voluntario/deletar")
    public void deletar(@RequestBody VoluntarioModel voluntario) {
        repository.deleteById(voluntario.codigo);
    }


    @PutMapping("/api/voluntario/atualizar")
    public VoluntarioModel atualizar(@RequestBody VoluntarioModel voluntario) {
        return repository.save(voluntario);
    }}
