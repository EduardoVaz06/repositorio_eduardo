package meu_trabalho.rest.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeuTrabalhoApplicationTests {

	@Test
	void contextLoads() {
	}

}
